using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using System.Security.Claims;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/events
        [HttpGet]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.EventCategories)
                    .ThenInclude(ec => ec.Category)
                .Where(e => e.IsActive)
                .OrderBy(e => e.EventDate)
                .Select(e => new EventDto
                {
                    EventID = e.EventID,
                    EventName = e.EventName,
                    Description = e.Description,
                    EventDate = e.EventDate,
                    Location = e.Location,
                    Venue = e.Venue,
                    DistanceKm = e.DistanceKm,
                    RouteMapURL = e.RouteMapURL,
                    OrganiserName = e.Organiser!.FirstName + " " + e.Organiser.LastName,
                    Categories = e.EventCategories.Select(ec => new EventCategoryDto
                    {
                        EventCategoryID = ec.EventCategoryID,
                        CategoryName = ec.Category!.CategoryName,
                        EntryFee = ec.EntryFee,
                        MaxParticipants = ec.MaxParticipants,
                        CurrentParticipants = ec.CurrentParticipants
                    }).ToList()
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/events/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var e = await _context.Events
                .Include(e => e.Organiser)
                .Include(e => e.EventCategories)
                    .ThenInclude(ec => ec.Category)
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (e == null)
                return NotFound(new { message = "Event not found" });

            return Ok(new EventDto
            {
                EventID = e.EventID,
                EventName = e.EventName,
                Description = e.Description,
                EventDate = e.EventDate,
                Location = e.Location,
                Venue = e.Venue,
                DistanceKm = e.DistanceKm,
                RouteMapURL = e.RouteMapURL,
                OrganiserName = e.Organiser!.FirstName + " " + e.Organiser.LastName,
                Categories = e.EventCategories.Select(ec => new EventCategoryDto
                {
                    EventCategoryID = ec.EventCategoryID,
                    CategoryName = ec.Category!.CategoryName,
                    EntryFee = ec.EntryFee,
                    MaxParticipants = ec.MaxParticipants,
                    CurrentParticipants = ec.CurrentParticipants
                }).ToList()
            });
        }

        // POST: api/events
        [Authorize(Roles = "Organiser")]
        [HttpPost]
        public async Task<IActionResult> CreateEvent([FromBody] CreateEventDto dto)
        {
            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var newEvent = new Event
            {
                OrganiserID = organiserId,
                EventName = dto.EventName,
                Description = dto.Description,
                EventDate = dto.EventDate,
                Location = dto.Location,
                Venue = dto.Venue,
                DistanceKm = dto.DistanceKm,
                RouteMapURL = dto.RouteMapURL
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEvent), new { id = newEvent.EventID }, newEvent);
        }

        // PUT: api/events/5
        [Authorize(Roles = "Organiser")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] CreateEventDto dto)
        {
            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var existing = await _context.Events.FirstOrDefaultAsync(e => e.EventID == id);

            if (existing == null)
                return NotFound(new { message = "Event not found" });

            if (existing.OrganiserID != organiserId)
                return StatusCode(403, new { message = "You can only edit your own events" });

            existing.EventName = dto.EventName;
            existing.Description = dto.Description;
            existing.EventDate = dto.EventDate;
            existing.Location = dto.Location;
            existing.Venue = dto.Venue;
            existing.DistanceKm = dto.DistanceKm;
            existing.RouteMapURL = dto.RouteMapURL;
            existing.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(existing);
        }

        // DELETE: api/events/5
        [Authorize(Roles = "Organiser")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var organiserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var existing = await _context.Events.FirstOrDefaultAsync(e => e.EventID == id);

            if (existing == null)
                return NotFound(new { message = "Event not found" });

            if (existing.OrganiserID != organiserId)
                return StatusCode(403, new { message = "You can only delete your own events" });

            existing.IsActive = false;
            existing.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}