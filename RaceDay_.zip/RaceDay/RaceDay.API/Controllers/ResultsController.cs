using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using System.Security.Claims;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/results
        [HttpGet]
        public async Task<IActionResult> GetResults()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var role = User.FindFirst(ClaimTypes.Role)!.Value;

            var query = _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e!.Event)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e!.Participant)
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e!.EventCategory)
                        .ThenInclude(ec => ec!.Category)
                .AsQueryable();

            // Participants only see their own results
            if (role == "Participant")
            {
                query = query.Where(r => r.Enrolment!.ParticipantID == userId);
            }

            var results = await query.Select(r => new ResultDto
            {
                ResultID = r.ResultID,
                EnrolmentID = r.EnrolmentID,
                ParticipantName = r.Enrolment!.Participant!.FirstName + " " + r.Enrolment.Participant.LastName,
                EventName = r.Enrolment.Event!.EventName,
                CategoryName = r.Enrolment.EventCategory!.Category!.CategoryName,
                FinishTime = r.FinishTime,
                Position = r.Position,
                OverallRank = r.OverallRank,
                CategoryRank = r.CategoryRank,
                PacePerKm = r.PacePerKm,
                Verified = r.Verified
            }).ToListAsync();

            return Ok(results);
        }

        // POST: api/results
        [Authorize(Roles = "Organiser")]
        [HttpPost]
        public async Task<IActionResult> CreateResult([FromBody] CreateResultDto dto)
        {
            // Check if result already exists
            var existing = await _context.Results
                .FirstOrDefaultAsync(r => r.EnrolmentID == dto.EnrolmentID);

            if (existing != null)
                return Conflict(new { message = "A result already exists for this enrolment" });

            var enrolment = await _context.Enrolments.FindAsync(dto.EnrolmentID);
            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            var result = new Result
            {
                EnrolmentID = dto.EnrolmentID,
                FinishTime = dto.FinishTime,
                Position = dto.Position,
                OverallRank = dto.OverallRank,
                CategoryRank = dto.CategoryRank,
                PacePerKm = dto.PacePerKm,
                Verified = false
            };

            _context.Results.Add(result);

            // Mark enrolment as completed
            enrolment.Status = "Completed";

            await _context.SaveChangesAsync();

            return Ok(new { message = "Result captured successfully", resultID = result.ResultID });
        }

        // PUT: api/results/5
        [Authorize(Roles = "Organiser")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateResult(int id, [FromBody] CreateResultDto dto)
        {
            var result = await _context.Results.FindAsync(id);
            if (result == null)
                return NotFound(new { message = "Result not found" });

            result.FinishTime = dto.FinishTime;
            result.Position = dto.Position;
            result.OverallRank = dto.OverallRank;
            result.CategoryRank = dto.CategoryRank;
            result.PacePerKm = dto.PacePerKm;
            result.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return Ok(result);
        }
    }
}// ResultsController - Manages race results


