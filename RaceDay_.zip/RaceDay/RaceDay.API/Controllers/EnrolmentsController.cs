using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using System.Security.Claims;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/enrolments
        [HttpGet]
        public async Task<IActionResult> GetEnrolments()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
            var role = User.FindFirst(ClaimTypes.Role)!.Value;

            var query = _context.Enrolments
                .Include(e => e.Event)
                .Include(e => e.Participant)
                .Include(e => e.EventCategory)
                    .ThenInclude(ec => ec!.Category)
                .AsQueryable();

            // Participants only see their own enrolments
            if (role == "Participant")
            {
                query = query.Where(e => e.ParticipantID == userId);
            }

            var enrolments = await query.Select(e => new EnrolmentDto
            {
                EnrolmentID = e.EnrolmentID,
                EventID = e.EventID,
                EventName = e.Event!.EventName,
                CategoryName = e.EventCategory!.Category!.CategoryName,
                ParticipantName = e.Participant!.FirstName + " " + e.Participant.LastName,
                EnrolmentDate = e.EnrolmentDate,
                Status = e.Status,
                PaymentStatus = e.PaymentStatus,
                BibNumber = e.BibNumber
            }).ToListAsync();

            return Ok(enrolments);
        }

        // POST: api/enrolments
        [Authorize(Roles = "Participant")]
        [HttpPost]
        public async Task<IActionResult> CreateEnrolment([FromBody] CreateEnrolmentDto dto)
        {
            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            // Check if already enrolled
            var existing = await _context.Enrolments
                .FirstOrDefaultAsync(e => e.ParticipantID == participantId && e.EventID == dto.EventID);

            if (existing != null)
                return Conflict(new { message = "You are already enrolled in this event" });

            // Find the event category
            var eventCategory = await _context.EventCategories
                .Include(ec => ec.Category)
                .FirstOrDefaultAsync(ec => ec.EventID == dto.EventID && ec.CategoryID == dto.CategoryID);

            if (eventCategory == null)
                return NotFound(new { message = "Event category not found" });

            // Check if category is full
            if (eventCategory.CurrentParticipants >= eventCategory.MaxParticipants)
                return BadRequest(new { message = "This category is full" });

            var enrolment = new Enrolment
            {
                EventID = dto.EventID,
                ParticipantID = participantId,
                EventCategoryID = eventCategory.EventCategoryID,
                Status = "Confirmed",
                PaymentStatus = "Pending"
            };

            _context.Enrolments.Add(enrolment);

            // Update participant count
            eventCategory.CurrentParticipants++;

            await _context.SaveChangesAsync();

            return Ok(new { message = "Successfully enrolled", enrolmentID = enrolment.EnrolmentID });
        }

        // DELETE: api/enrolments/5
        [Authorize(Roles = "Participant")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelEnrolment(int id)
        {
            var participantId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

            var enrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e => e.EnrolmentID == id);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found" });

            if (enrolment.ParticipantID != participantId)
                return StatusCode(403, new { message = "You can only cancel your own enrolments" });

            var eventCategory = await _context.EventCategories.FindAsync(enrolment.EventCategoryID);
            if (eventCategory != null && eventCategory.CurrentParticipants > 0)
            {
                eventCategory.CurrentParticipants--;
            }

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}// EnrolmentsController - Manages event enrolments


